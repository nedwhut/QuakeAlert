<?php

require_once('db.php');

 if (!isset($_POST['location']) && !isset($_POST['reporter']) ){
   die("Error incomplete HTTP request");



 }

 if (strlen($_POST['location']) < 3  || strlen($_POST['reporter']) < 3) {

   die("Error plese fill in the form");

 }

//kena filter semua input, bahaya kalau tak filter
$POSTV = filter_input_array(INPUT_POST,
    ['location' => FILTER_SANITIZE_STRING,
     'description' => FILTER_SANITIZE_STRING,
     'lat' => FILTER_SANITIZE_STRING,
     'lng' => FILTER_SANITIZE_STRING,
     'reporter' => FILTER_SANITIZE_STRING,
    ]
);
$location = $POSTV['location'];
$description = $POSTV['description'];
$lat = $POSTV['lat'];
$lng = $POSTV['lng'];
$reporter = $POSTV['reporter'];


$query= "INSERT INTO hazard (location, description, lat, lng, reporter)
VALUES ('$location','$description', '$lat', '$lng','$reporter')";

$result=mysqli_query($link, $query);

if (!$result) {

  echo mysqli_error($link);

} else {

echo "Data succesfully inserted";

}


 ?>
