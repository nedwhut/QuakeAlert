package com.example.quakealert;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Hazard {

    @SerializedName("id")
    @Expose
    public String id;
    @SerializedName("location")
    @Expose
    public String location;
    @SerializedName("description")
    @Expose
    public String description;
    @SerializedName("lat")
    @Expose
    public String lat;
    @SerializedName("lng")
    @Expose
    public String lng;
    @SerializedName("reporter")
    @Expose
    public String reporter;
    @SerializedName("date")
    @Expose
    public String date;

}