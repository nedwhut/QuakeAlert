package com.example.quakealert;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class AdminNews extends AppCompatActivity {
    EditText titlee, content;
    RequestQueue queue;
    final String url = "http://192.168.87.45/news/api.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_news);

        queue = Volley.newRequestQueue(getApplicationContext());

        titlee = (EditText) findViewById(R.id.titlee);
        content = (EditText) findViewById(R.id.content);
        Button send = (Button) findViewById(R.id.send);
        Button reset = (Button) findViewById(R.id.reset);

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //volley call

                makeRequest();
            }
        });

        reset.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick (View v){
                titlee.setText("");
                content.setText("");

                Toast.makeText(AdminNews.this, "Item cleared", Toast.LENGTH_LONG).show();
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate (R.menu.menu, menu);

        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.hazard:
                //Toast.makeText(this, "This is about", Toast.LENGTH_LONG).show();

                Intent intent = new Intent(this, AdminHazard.class);
                startActivity(intent);

                break;

            case R.id.news:
                Intent intent2 = new Intent(this, AdminNews.class);
                startActivity(intent2);

                break;
        }

        return true;
    }

    public void makeRequest() {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

            }
        },errorListener) {
            @Override
            protected Map<String, String> getParams () {
                Map <String, String> params = new HashMap<>();

                params.put("titlee", titlee.getText().toString());
                params.put("content", content.getText().toString());

                return params;
            }
        };
        queue.add(stringRequest);
    }

    public Response.ErrorListener errorListener = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
        }
    };
}