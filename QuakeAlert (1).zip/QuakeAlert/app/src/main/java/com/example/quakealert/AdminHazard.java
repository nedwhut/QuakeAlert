package com.example.quakealert;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.quakealert.AdminNews;
import com.example.quakealert.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class AdminHazard extends AppCompatActivity {
    TextView lat, lon;
    private LocationCallback locationCallback;
    LocationRequest locationRequest;
    EditText location, description, reporter;
    RequestQueue queue;
    final String url = "http://192.168.40.45/hazard/api.php";

    String[] perms = {"android.permission.ACCESS_FINE_LOCATION",
            "android.permission.ACCESS_COARSE_LOCATION",
            "android.permission.INTERNET",
            "android.permission.ACCESS_NETWORK_STATE"};

    private FusedLocationProviderClient fusedLocationClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.admin_hazard);

        queue = Volley.newRequestQueue(getApplicationContext());

        lat = (TextView) findViewById(R.id.lat);
        lon = (TextView) findViewById(R.id.lon);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        location = (EditText) findViewById(R.id.location);
        description = (EditText) findViewById(R.id.description);
        reporter = (EditText) findViewById(R.id.reporter);
        Button submit = (Button) findViewById(R.id.submit);
        Button clear = (Button) findViewById(R.id.clear);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //volley call

                makeRequest();
            }
        });

        clear.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick (View v){
                location.setText("");
                lat.setText("");
                lon.setText("");
                description.setText("");
                reporter.setText("");

                Toast.makeText(AdminHazard.this, "Item cleared", Toast.LENGTH_LONG).show();
            }
        });

        //check permission / permission request
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, perms, 200);
            return;
        }
        locationRequest = LocationRequest.create();

        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        locationRequest.setInterval(10 * 1000); // in milisecond, 1000 = 1 second
        locationRequest.setFastestInterval(2000); // 2 second

        locationCallback = new LocationCallback() {
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    Toast.makeText(getApplicationContext(), "Unable detect location", Toast.LENGTH_SHORT).show();
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    // Update UI with location data
                    double latitude = location.getLatitude();
                    double longitude = location.getLongitude();

                    lat.setText("" + latitude);
                    lon.setText( "" + longitude);
                }
            }
        };

        fusedLocationClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                double latitude = location.getLatitude();
                double longitude = location.getLongitude();

                lat.setText("" + latitude);
                lon.setText( "" + longitude);

            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate (R.menu.menu, menu);

        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.hazard:
                //Toast.makeText(this, "This is about", Toast.LENGTH_LONG).show();

                Intent intent = new Intent(this, AdminHazard.class);
                startActivity(intent);

                break;

            case R.id.news:
                Intent intent2 = new Intent(this, AdminNews.class);
                startActivity(intent2);

                break;
        }

        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();

        startLocationUpdates();
    }

    private void startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        fusedLocationClient.requestLocationUpdates(locationRequest,
                locationCallback,
                Looper.getMainLooper());
    }

    public void makeRequest() {

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

            }
        },errorListener) {
            @Override
            protected Map<String, String> getParams () {
                Map <String, String> params = new HashMap<>();

                params.put("location", location.getText().toString());
                params.put("description", description.getText().toString());
                params.put("lat", lat.getText().toString());
                params.put("lon", lon.getText().toString());
                params.put("reporter", reporter.getText().toString());

                return params;
            }
        };
        queue.add(stringRequest);
    }

    public Response.ErrorListener errorListener = new Response.ErrorListener() {
        @Override
        public void onErrorResponse(VolleyError error) {
            Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
        }
    };
}