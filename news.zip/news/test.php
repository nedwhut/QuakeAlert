<?php

require_once('db.php');

$query = "SELECT * FROM news";
$result=mysqli_query($link,$query);
?>