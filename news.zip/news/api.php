<?php

require_once('db.php');

 if (!isset($_POST['titlee']) && !isset($_POST['content']) ){
   die("Error incomplete HTTP request");



 }

 if (strlen($_POST['titlee']) < 3  || strlen($_POST['content']) < 3) {

   die("Error plese fill in the form");

 }

//kena filter semua input, bahaya kalau tak filter
$POSTV = filter_input_array(INPUT_POST,
    ['titlee' => FILTER_SANITIZE_STRING,
     'content' => FILTER_SANITIZE_STRING,
    ]
);
$titlee = $POSTV['titlee'];
$content = $POSTV['content'];


$query= "INSERT INTO news (titlee, content)
VALUES ('$titlee','$content')";

$result=mysqli_query($link, $query);

if (!$result) {

  echo mysqli_error($link);

} else {

echo "News posted";

}


 ?>
