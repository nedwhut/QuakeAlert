<?php

    require_once('db.php');

    $query = "SELECT * FROM news";
    $result=mysqli_query($link,$query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Start your development with Steller landing page.">
    <meta name="author" content="Devcrud">
    <title>QuakeAlert</title>
    <!-- font icons -->
    <link rel="stylesheet" href="assets/vendors/themify-icons/css/themify-icons.css">
    <!-- Bootstrap + Steller main styles -->
	<link rel="stylesheet" href="assets/css/steller.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet" />
</head>
<body>

    <!-- Page navigation -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand" href="#"><img src="assets/imgs/logo.png" alt=""></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto align-items-center">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="hazard.php">Hazard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="news.php">News</a>
                    </li>                   
                </ul>
            </div>
        </div>          
    </nav><br><br>
    <!-- End of page navibation -->

    <div class="container-fluid">
      <div class="container">
        <div class="text-center">
          <h5
            class="text-primary text-uppercase mb-3"
            style="letter-spacing: 5px"
          >
            INSERT NEWS
          </h5>
        </div>
        <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="contact-form rounded p-5">          
                      <form action="insertnews.php" method="POST">
                      <div class="control-group">
                          <input type="text" class="form-control m-2" name="title" placeholder="Title">
                      </div>
                      <div class="control-group">
                          <textarea class="form-control m-2" name="content" rows="5" placeholder="Content"></textarea>
                      </div><br>
                            <div class="text-center">
                                <button class="btn btn-primary py-3 px-5" type="submit" id="submitButton" name="create">Create</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
      </div>
    </div>

    <div class="container pt-5">
        <table class="table table-hover">
        <thead>
            <tr>
            <th scope="col">ID</th>
            <th scope="col">Title</th>
            <th scope="col">Date</th>
            <th scope="col">Content</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($result as $row) { ?>
            <tr>
            <th scope="row"><?=$row['id']?></th>
            <td><?=$row['titlee']?></td>
            <td><?=$row['date']?></td>
            <td><?=$row['content']?></td>
            </tr>
            <?php } ?>
        </tbody>
        </table>
    </div>
<br>
</body>
</html>