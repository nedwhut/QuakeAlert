<?php
    include 'db.php';
    $location = $_POST['location'];
    $description = $_POST['description'];
    $lat = $_POST['lat'];
    $lng = $_POST['lng'];
    $reporter = $_POST['reporter'];

    $query= "INSERT INTO hazard (location, description, lat, lng, reporter)
VALUES ('$location','$description', '$lat', '$lng','$reporter')";

    $result=mysqli_query($link, $query);
    header("Location: hazard.php");
?>