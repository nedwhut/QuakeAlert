<?php
    include 'db.php';
    $titlee = $_POST['title'];
    $content = $_POST['content'];

    $query= "INSERT INTO news (titlee, content)
    VALUES ('$titlee','$content')";

    $result=mysqli_query($link, $query);
    header("Location: news.php");
?>