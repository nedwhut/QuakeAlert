<?php
    include 'db.php';
    $sql1="select count(*) as hazard from hazard;";
    $result1=mysqli_query($link,$sql1);
    $data1=mysqli_fetch_assoc($result1);
    $link -> close();
?>

<?php
    include 'db.php';
    $sql2="select count(*) as news from news;";
    $result2=mysqli_query($link,$sql2);
    $data2=mysqli_fetch_assoc($result2);
    $link -> close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Start your development with Steller landing page.">
    <meta name="author" content="Devcrud">
    <title>QuakeAlert</title>
    <!-- font icons -->
    <link rel="stylesheet" href="assets/vendors/themify-icons/css/themify-icons.css">
    <!-- Bootstrap + Steller main styles -->
	<link rel="stylesheet" href="assets/css/steller.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,700&display=swap" rel="stylesheet" />
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="40" id="home">

    <!-- Page navigation -->
    <nav class="navbar navbar-expand-lg navbar-light fixed-top" data-spy="affix" data-offset-top="0">
        <div class="container">
            <a class="navbar-brand" href="#"><img src="assets/imgs/logo.png" alt=""></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto align-items-center">
                    <li class="nav-item">
                        <a class="nav-link active" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="hazard.php">Hazard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="news.php">News</a>
                    </li>                   
                </ul>
            </div>
        </div>          
    </nav>
    <!-- End of page navibation -->

    <!-- Page Header -->
    <header class="header" id="home">
        <div class="container">
            <div class="infos">
                <h6 class="subtitle">Welcome to</h6>
                <h6 class="title">QuakeAlert</h6>
                <p>Administrator</p>

                <div class="buttons pt-3">
                    <a href="hazard.php"><button class="btn btn-primary rounded">HAZARD</button></a>
                    <a href="news.php"><button class="btn btn-dark rounded">NEWS</button></a>
                </div>      
            </div>              
            <div class="img-holder">
                <img src="assets/imgs/man.svg" alt="">
            </div>      
        </div>  

        <!-- Header-widget -->
        <div class="widget">
            <div class="widget-item">
                <h2><?php echo $data1['hazard']; ?></h2>
                <p>Hazard Reported</p>
            </div>
            <div class="widget-item">
                <h2><?php echo $data2['news']; ?></h2>
                <p>News Reported</p>
            </div>
        </div>
    </header>
    <!-- End of Page Header -->

    <!-- Page Footer -->
    <footer class="page-footer mt-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <p>Copyright <script>document.write(new Date().getFullYear())</script> &copy; <a href="http://www.devcrud.com" target="_blank">QuakeAlert</a></p>
                </div>
            </div>
        </div>
    </footer> 
    <!-- End of page footer -->
	
	<!-- core  -->
    <script src="assets/vendors/jquery/jquery-3.4.1.js"></script>
    <script src="assets/vendors/bootstrap/bootstrap.bundle.js"></script>
    <!-- bootstrap 3 affix -->
	<script src="assets/vendors/bootstrap/bootstrap.affix.js"></script>

    <!-- steller js -->
    <script src="assets/js/steller.js"></script>

</body>
</html>
